import os, json, random
from typing import List, Dict
from datasets import Dataset
from transformers import T5ForConditionalGeneration, T5Tokenizer, Trainer, TrainingArguments

# Minimal fine-tuning script for small CPU-friendly training
HERE = os.path.dirname(__file__)
DATA_PATH = os.path.join(HERE, "recipes_dataset.json")
OUT_DIR = os.path.join(HERE, "model_recipes")

def build_pairs(data: List[Dict]):
    inputs, targets = [], []
    for row in data:
        inp = f"Ingredients: {row['input']}\nRecipe:"
        tgt = row['output']
        inputs.append(inp)
        targets.append(tgt)
    return inputs, targets

def main():
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    random.shuffle(data)

    tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-small")
    model = T5ForConditionalGeneration.from_pretrained("google/flan-t5-small")

    inputs, targets = build_pairs(data)

    def tokenize_batch(batch):
        model_inputs = tokenizer(batch["input_text"], max_length=128, truncation=True, padding="max_length")
        labels = tokenizer(batch["target_text"], max_length=128, truncation=True, padding="max_length")
        model_inputs["labels"] = labels["input_ids"]
        return model_inputs

    ds = Dataset.from_dict({"input_text": inputs, "target_text": targets})
    ds = ds.map(tokenize_batch, batched=True, remove_columns=["input_text", "target_text"])

    args = TrainingArguments(
        output_dir=os.path.join(HERE, "tmp_out"),
        per_device_train_batch_size=4,
        num_train_epochs=2,
        learning_rate=3e-4,
        save_strategy="no",
        logging_steps=5,
        report_to=[],
        fp16=False
    )

    trainer = Trainer(model=model, args=args, train_dataset=ds)
    trainer.train()

    os.makedirs(OUT_DIR, exist_ok=True)
    model.save_pretrained(OUT_DIR)
    tokenizer.save_pretrained(OUT_DIR)
    print(f"Saved fine-tuned model to: {OUT_DIR}")

if __name__ == "__main__":
    main()
