from fastapi import FastAPI
from pydantic import BaseModel
from model_handler import load_model, generate_recipe

app = FastAPI(title="Local LLM Recipe Chatbot", version="1.0.0")

# Load once at startup
model = load_model()

class Ingredients(BaseModel):
    items: str

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/get_recipe")
def get_recipe(data: Ingredients):
    recipe = generate_recipe(model, data.items)
    return {"ingredients": data.items, "recipe": recipe}
