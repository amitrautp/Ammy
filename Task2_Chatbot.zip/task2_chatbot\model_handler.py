import os
from transformers import pipeline

MODEL_DIR = os.path.join(os.path.dirname(__file__), "model_recipes")

def load_model():
    # If a fine-tuned model exists locally, prefer it; otherwise use a small base model
    model_name = MODEL_DIR if os.path.isdir(MODEL_DIR) else "google/flan-t5-small"
    return pipeline("text2text-generation", model=model_name)

def generate_recipe(model, ingredients: str) -> str:
    prompt = (
        "You are a helpful cooking assistant. "
        "Given a comma-separated list of ingredients, suggest a simple, tasty recipe "
        "with steps and approximate quantities. Be concise.\n\n"
        f"Ingredients: {ingredients}\nRecipe:"
    )
    out = model(prompt, max_length=220, do_sample=True, top_p=0.9, temperature=0.7)[0]["generated_text"]
    # Some models echo the prompt; keep only the part after 'Recipe:' if present
    if "Recipe:" in out:
        out = out.split("Recipe:", 1)[-1].strip()
    return out
