import requests

API_URL = "http://127.0.0.1:8000/get_recipe"

def main():
    print("🍳 Recipe Chatbot — type ingredients like 'Egg, Onion' (type 'exit' to quit)")
    while True:
        try:
            ingredients = input("\nEnter ingredients: ").strip()
            if not ingredients:
                print("Please enter something (or 'exit').")
                continue
            if ingredients.lower() == "exit":
                break
            resp = requests.post(API_URL, json={"items": ingredients}, timeout=60)
            if resp.ok:
                print("\n🍲 Suggested Recipe:\n")
                print(resp.json().get("recipe", "(no recipe returned)"))
            else:
                print("API error:", resp.status_code, resp.text)
        except KeyboardInterrupt:
            break

if __name__ == "__main__":
    main()
